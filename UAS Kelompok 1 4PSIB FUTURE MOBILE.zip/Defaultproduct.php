<?php
// include header.php file
include ('header.php');
?>

<?php

    /*  include products */
    include ('DefaultTemplate/_product.php');
    /*  include products */

    /*  include top sale section */
    include ('DefaultTemplate/_top-sale.php');
    /*  include top sale section */

?>

<?php
// include footer.php file
include ('footer.php');
?>

