<?php
    ob_start();
    // include header.php file
    include ('headerlogin.php');
?>

<?php
include ('Template/_Blogs.php');
?>

<?php
// include footer.php file
include ('footer.php');
?>