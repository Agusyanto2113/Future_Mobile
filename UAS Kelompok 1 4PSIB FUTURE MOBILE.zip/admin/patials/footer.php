       <!-- Footer Section Start -->
       <div class="footer">
        <div class="wrapper">
            <p class="text-center">2022 All rights reserved, Future Mobile,<a href="">By Kelompok 1</a></p>
        </div>
        </div>
        <!-- Footet Section Ends -->
    </body>
</html>