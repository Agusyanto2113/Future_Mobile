<!-- Owl-carousel -->
<section id="banner-area">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <a href="Login-Product.php"><img src="./assets/Banner1.png" alt="Banner1"></a>
        </div>
        <div class="item">
            <a href="Login-Product.php"><img src="./assets/Banner2.png" alt="Banner2"></a>
        </div>
        <div class="item">
            <a href="Login-Product.php"><img src="./assets/Banner1.png" alt="Banner3"></a>
        </div>
    </div>
</section>
<!-- !Owl-carousel -->
