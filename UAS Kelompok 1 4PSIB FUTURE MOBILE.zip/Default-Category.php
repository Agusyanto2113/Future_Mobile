<?php
    ob_start();
    // include header.php file
    include ('header.php');
?>

<?php
include ('DefaultTemplate/_Category.php');
?>

<?php
// include footer.php file
include ('footer.php');
?>